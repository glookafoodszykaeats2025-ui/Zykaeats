# 🔥 Zykaeats — Restaurant Ordering Website

Full-stack food ordering website for a Bangalore cloud kitchen.  
Razorpay payments · WhatsApp ordering · Admin panel · Mobile-first.

---

## Quick start (local)

```bash
git clone https://github.com/YOUR_USERNAME/zykaeats.git
cd zykaeats
npm install
cp .env.example .env      # fill in your keys
npm run dev               # http://localhost:3000
```

## Deploy to Render (free)

1. Push this repo to GitHub  
2. New Web Service on render.com → connect repo  
3. Build command: `npm install`  
4. Start command: `npm start`  
5. Add environment variables from `.env.example`  
6. Deploy — you'll get a live URL in ~3 minutes

## Environment variables

| Variable | Description |
|---|---|
| `RAZORPAY_KEY_ID` | From razorpay.com → Settings → API Keys |
| `RAZORPAY_KEY_SECRET` | Same place |
| `WHATSAPP_NUMBER` | Your number, no + or spaces e.g. `919876543210` |
| `ADMIN_PASSWORD` | Password for /admin panel |
| `PORT` | Default 3000 |

## URLs

| URL | What |
|---|---|
| `/` | Customer ordering website |
| `/admin` | Admin panel (menu + orders) |
| `/api/menu` | Menu JSON API |
| `/api/orders` | Orders API (admin token required) |
| `/health` | Server health check |

## Stack

Node.js · Express · Razorpay · WhatsApp wa.me · Vanilla JS · HTML/CSS
